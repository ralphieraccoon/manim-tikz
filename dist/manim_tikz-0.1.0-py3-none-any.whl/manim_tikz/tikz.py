from .template import TikzTemplate

from typing import List
from manim.mobject.svg.svg_mobject import SVGMobject
from manim.utils.tex_file_writing import tex_to_svg_file


class Tikz(SVGMobject):

    def __init__(
        self,
        code: str,
        libraries: List[str] = [],
        tikzset: List[str] = [],
        use_pdf=False,
        **kwargs,
    ):
        file_name = self.convert(code, libraries, tikzset, use_pdf)
        super().__init__(
            file_name,
            **kwargs,
        )

    def convert(self, code, libraries, tikzset, use_pdf):
        return tex_to_svg_file(
            code,
            environment="tikzpicture",
            tex_template=TikzTemplate(libraries, tikzset, use_pdf)
        )