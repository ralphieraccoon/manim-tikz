# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['manim_tikz']

package_data = \
{'': ['*']}

install_requires = \
['manim>=0.17.0']

entry_points = \
{'manim.plugins': ['manim_tikz = module:object.attr']}

setup_kwargs = {
    'name': 'manim-tikz',
    'version': '0.1.1',
    'description': 'Converts Tikz markup code into an SVGMobject for use in manim.',
    'long_description': 'None',
    'author': 'Ralphie Raccoon',
    'author_email': 'damian.crosby@manchester.ac.uk',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
