# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['manim_tikz']

package_data = \
{'': ['*']}

install_requires = \
['manim @ git+https://github.com/ManimCommunity/manim.git@main']

entry_points = \
{'manim.plugins': ['manim_tikz = module:object.attr']}

setup_kwargs = {
    'name': 'manim-tikz',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'Ralphie Raccoon',
    'author_email': 'damian.crosby@manchester.ac.uk',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
