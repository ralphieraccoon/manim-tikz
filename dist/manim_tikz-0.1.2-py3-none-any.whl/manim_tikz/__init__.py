__version__ = '0.1.0'

from manim import *

from .tikz import Tikz
from .template import TikzTemplate


